<?php

namespace App\Http\Controllers\Api;

use App\ApiData;
use App\Http\Controllers\Controller;
use App\Models\Note;
use Illuminate\Http\Request;

class NoteController extends Controller
{
    public function list(){
        $notes = Note::all();
        ApiData::S($notes);
    }


    public function store(Request $request){
        $note = new Note();
        $note->name = $request->name;
        $note->detail = $request->detail;
        $note->semester_id = $request->semester_id;
        $note->user_id = $request->user_id;
        $note->image = $request->image->store('note/data');
        $note->save();
        ApiData::S($note);
    }

    public function update(Request $request){
        $note = Note::where('id',$request->id)->first();
        $note->name = $request->name;
        $note->detail = $request->detail;
        $note->semester_id = $request->semester_id;
        $note->user_id = $request->user_id;
        $note->image = $request->image->store('note/data');
        $note->save();
        ApiData::S($note);
    }

    public function delete(Request $request){
        $univer = Note::where('id',$request->id)->first();
        $univer->delete();
        ApiData::S(['Ok']);
    }

}
