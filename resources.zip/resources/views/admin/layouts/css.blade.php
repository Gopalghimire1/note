<style>
    .table td, .table th{
        padding:0px 5px;
        vertical-align: inherit;
    }
</style>