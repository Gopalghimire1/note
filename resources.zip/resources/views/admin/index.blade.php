@extends('admin.layouts.app')
@section('title','Dashboard')
@section('content')
    <div class="row">

        <div class="col-md-2 section href">
            <span class="icon">
                <i class="zmdi zmdi-markunread-mailbox"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Hello
            </span>
        </div>
    </div>
@endsection
