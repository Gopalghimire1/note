<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('login','Api/AbcController@login');

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::middleware('auth:api')->group(function () {
    Route::prefix('university')->group(function () {
        Route::post('add','Api\UniversityController@store');
        Route::post('update','Api\UniversityController@update');
        Route::post('delete','Api\UniversityController@delete');
        Route::get('list','Api\UniversityController@list');
    });

    Route::prefix('faculty')->group(function () {
        Route::post('add','Api\FacultyController@store');
        Route::post('update','Api\FacultyController@update');
        Route::post('delete','Api\FacultyController@delete');
        Route::get('list','Api\FacultyController@list');
    });

    Route::prefix('semester')->group(function () {
        Route::post('add','Api\SemesterController@store');
        Route::post('update','Api\SemesterController@update');
        Route::post('delete','Api\SemesterController@delete');
        Route::get('list','Api\SemesterController@list');
    });
});
