<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-2 section href">
            <span class="icon">
                <i class="zmdi zmdi-markunread-mailbox"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Hello
            </span>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\NeedTechnoSoft\laravel\note\resources\views/admin/index.blade.php ENDPATH**/ ?>