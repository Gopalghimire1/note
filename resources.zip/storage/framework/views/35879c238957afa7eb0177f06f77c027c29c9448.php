<?php $__env->startSection('title','Universities'); ?>
<?php $__env->startSection('head-title','Universities'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('calender/nepali.datepicker.v3.2.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('backend/plugins/select2/select2.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('toobar'); ?>
<div class="p-4 mb-2 cc1" style="background-color: white; border-radius: 10px">
    <form id="form_validation" action="<?php echo e(route('admin.university.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6">
                <label for="name">University Name</label>
                <div class="form-group">
                    <input type="text" name="name" class="form-control" placeholder="Enter university name" required>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="form-group" style="margin-top:30px;">
                    <button class="btn btn-primary btn-block">Submit Data</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="table-responsive">
    <table id="newstable1" class="table table-bordered table-striped table-hover js-basic-example dataTable">
        <thead>
            <tr>
                <th>University Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="expenseData">
           <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <form id="edit" action="<?php echo e(route('admin.university.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <tr>
                        <td>
                            <input type="hidden"  name="id" value="<?php echo e($u->id); ?>">
                            <input type="text" class="form-control" name="name" value="<?php echo e($u->name); ?>">
                        </td>
                        <td><button class="btn btn-primary btn-sm">Update</button></td>
                    </tr>
               </form>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('calender/nepali.datepicker.v3.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/select2/select2.min.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\NeedTechnoSoft\laravel\note\resources\views/admin/university/index.blade.php ENDPATH**/ ?>